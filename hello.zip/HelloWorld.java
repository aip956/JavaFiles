import edu.princeton.cs.algs4.StdOut;
public class HelloWorld {
    public static void main(String[] arg) {
        StdOut.println("Hello World");
    }
}
