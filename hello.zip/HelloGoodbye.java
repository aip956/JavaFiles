import edu.princeton.cs.algs4.StdOut;
public class HelloGoodbye {
    public static void main(String[] args) {
        StdOut.println("Hello, Goodbye");
    }
}
