import edu.princeton.cs.algs4.StdOut;

public class RandomWord {
    public static void main(String[] args) {
        StdOut.println("Random Word");
    }
}
